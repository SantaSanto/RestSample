package com.rest.sample.service;

import com.rest.sample.model.Student;

public interface RestService {
	
	Student getStudentById(int id);
	
}
